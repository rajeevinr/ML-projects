from taipy.gui import builder as tgb
from taipy.gui import Gui
from pathlib import Path
favicon_path = Path("favicon.png")
with tgb.Page() as page:
    if favicon_path.exists():
        tgb.text("The favicon exists ")
    tgb.text("Where is my favicon?")
    
Gui(page,).run(debug=True, use_reloader=True, port=5111, favicon=str(favicon_path))