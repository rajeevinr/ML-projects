import fitz  # PyMuPDF

def modify_pdf(input_pdf, output_pdf, old_word, new_word, vertical_offset=2):
    # Open the original PDF
    doc = fitz.open(input_pdf)
    
    # Iterate over each page in the document
    for page_num in range(len(doc)):
        page = doc.load_page(page_num)  # Load the page
        
        # Search for the old word in the document
        text_instances = page.search_for(old_word)
        
        for inst in text_instances:
            # The bounding box of the old word (position and size)
            rect = inst  # The bounding box of the old word
            
            # Erase the old word by drawing a white rectangle over it
            page.draw_rect(rect, color=(1, 1, 1), fill=True)  # White rectangle (fill=True)
            
            # Retrieve the font size of the old word
            font_size = rect.height  # Approximation based on the height of the bounding box
            
            # Adjust the vertical position (move the new word slightly down)
            new_y_position = rect.y1 + vertical_offset - 9  # Move the y-coordinate down
            
            # Insert the new word at the adjusted position
            page.insert_text(
                (rect.x0, new_y_position),  # Insert at the bottom-left corner, but adjusted vertically
                new_word,  # The new word to insert
                fontsize=font_size,  # Match the old word's font size
                color=(0, 0, 0)  # Black color for the new word
            )
    
    # Save the modified PDF
    doc.save(output_pdf)
    print(f"Modified PDF saved as: {output_pdf}")

# Example usage
input_pdf = "310 Freight Invoice Version 4010.pdf"
output_pdf = "modified_output.pdf"
old_word = "Freight"
new_word = "name"

modify_pdf(input_pdf, output_pdf, old_word, new_word)
