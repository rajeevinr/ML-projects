import fitz  # PyMuPDF

def modify_pdf(input_pdf, output_pdf, old_word, new_word):
    # Open the original PDF
    doc = fitz.open(input_pdf)
    
    # Iterate over each page in the document
    for page_num in range(len(doc)):
        page = doc.load_page(page_num)  # Load the page
        
        # Search for the text (old_word) and get its bounding box (position)
        text_instances = page.search_for(old_word)
        
        for inst in text_instances:
            # Erase the old word by drawing a white rectangle over it
            page.draw_rect(inst, color=(1, 1, 1))  # White rectangle to cover the old word
            
            # Insert the new word at the same position
            page.insert_text(inst[:2], new_word, fontsize=12, color=(0, 0, 0))  # Black color for the new word
    
    # Save the modified PDF
    doc.save(output_pdf)
    print(f"Modified PDF saved as: {output_pdf}")

# Example usage
input_pdf = "310 Freight Invoice Version 4010.pdf"
output_pdf = "modified_output.pdf"
old_word = "Freight"
new_word = "abc"

modify_pdf(input_pdf, output_pdf, old_word, new_word)
