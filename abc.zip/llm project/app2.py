import pdfplumber
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

# Step 1: Extract text from the original PDF
def extract_text_from_pdf(pdf_path):
    with pdfplumber.open(pdf_path) as pdf:
        text = ""
        for page in pdf.pages:
            text += page.extract_text()
        return text

# Step 2: Modify the extracted text
def modify_text(original_text, old_word, new_word):
    return original_text.replace(old_word, new_word)

# Step 3: Create a new PDF with the modified text
def create_pdf_with_modified_text(modified_text, output_pdf):
    c = canvas.Canvas(output_pdf, pagesize=letter)
    width, height = letter
    c.setFont("Helvetica", 10)
    text_object = c.beginText(40, height - 40)
    text_object.textLines(modified_text)
    c.drawText(text_object)
    c.showPage()
    c.save()

# Main function to execute the steps
def main():
    pdf_path = '310 Freight Invoice Version 4010.pdf'
    output_pdf = 'modified_output.pdf'
    old_word = 'Freight'
    new_word = 'Abc'
    
    # Step 1: Extract text from PDF
    text = extract_text_from_pdf(pdf_path)
    
    # Step 2: Modify text
    modified_text = modify_text(text, old_word, new_word)
    
    # Step 3: Create new PDF
    create_pdf_with_modified_text(modified_text, output_pdf)
    print(f"New PDF created: {output_pdf}")

# Run the program
main()
