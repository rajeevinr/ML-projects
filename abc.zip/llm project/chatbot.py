import requests
from bs4 import BeautifulSoup
import openai
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

# Set up OpenAI API key
openai.api_key = "sk-proj-yWVjUopXSJ9q9xHaymOTOBX_42y1VXi2jPr36cpOQ0NduvB9sWYBZSmjBlX9-0LhNBCkccHtfF7T3BlbkFJgG17ME5t6hnEeyct8DEsY0RYDeDbkgLG3Gm0cp0XdOkIRvnwCAZc6V7bh4xc-LSXK6V0FkmzUA"

# Function to scrape the content of a webpage
def scrape_webpage(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Extract text from paragraphs and headings (this could be extended)
    paragraphs = soup.find_all(['p', 'h1', 'h2', 'h3', 'h4'])
    page_content = ' '.join([para.get_text() for para in paragraphs])
    return page_content

# Function to summarize the content using OpenAI GPT model
def summarize_content(content):
    prompt = f"Please summarize the following webpage content:\n\n{content}"
    
    response = openai.Completion.create(
        engine="text-davinci-003",  # Or another model of your choice
        prompt=prompt,
        max_tokens=500,  # Limit the summary to a reasonable size
        n=1,
        stop=None,
        temperature=0.7
    )
    
    summary = response.choices[0].text.strip()
    return summary

# Function to create a PDF document with the summary
def create_pdf(summary, output_filename="summary.pdf"):
    c = canvas.Canvas(output_filename, pagesize=letter)
    c.setFont("Helvetica", 12)
    width, height = letter  # 8.5 x 11 inches
    
    # Add title to the PDF
    c.drawString(100, height - 50, "Summary of Webpage")
    
    # Add the summary text to the PDF
    text_object = c.beginText(100, height - 100)
    text_object.setFont("Helvetica", 10)
    text_object.setTextOrigin(100, height - 100)
    text_object.textLines(summary)
    
    c.drawText(text_object)
    c.showPage()
    c.save()

# Chatbot Interface to process webpage URL and generate summary
def chatbot():
    print("Welcome to the Webpage Summarizer Chatbot!")
    print("Please provide the URL of the webpage you want to summarize.\n")

    # Get URL from the user
    url = input("Enter the URL: ")

    try:
        # Scrape content from the webpage
        print("Scraping webpage...")
        page_content = scrape_webpage(url)
        
        # Summarize the webpage content using OpenAI
        print("Summarizing content...")
        summary = summarize_content(page_content)
        
        # Output summary to the console
        print("\nSummary of the Webpage:")
        print(summary)
        
        # Ask if the user wants to save the summary to a PDF
        save_pdf = input("\nDo you want to save this summary as a PDF? (yes/no): ")
        if save_pdf.lower() == "yes":
            create_pdf(summary)
            print("Summary has been saved to 'summary.pdf'.")
        else:
            print("Summary was not saved to a PDF.")
    
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    chatbot()
