from flask import Flask, request, jsonify
from bs4 import BeautifulSoup
import requests

app = Flask(__name__)

def get_page_info(url):
  """Fetches and extracts basic information from a given webpage."""
  try:
    response = requests.get(url)
    response.raise_for_status()  # Raise an exception for bad status codes

    soup = BeautifulSoup(response.content, "html.parser")

    title = soup.title.string.strip() if soup.title else "No Title Found"
    description = soup.find("meta", attrs={"name": "description"})
    description = description["content"] if description else "No Description Found"
    keywords = soup.find("meta", attrs={"name": "keywords"})
    keywords = keywords["content"] if keywords else "No Keywords Found"

    return {
        "title": title,
        "description": description,
        "keywords": keywords
    }

  except requests.exceptions.RequestException as e:
    return {"error": f"Error fetching URL: {e}"}

@app.route('/get_info', methods=['POST'])
def get_webpage_info():
  """API endpoint to receive URL and return webpage information."""
  data = request.get_json()
  url = data.get('https://www.britannica.com')

  if not url:
    return jsonify({"error": "URL parameter is missing"}), 400

  page_info = get_page_info(url)
  return jsonify(page_info)

if __name__ == '__main__':
  app.run(debug=True)