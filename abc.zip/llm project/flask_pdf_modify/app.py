from flask import Flask, request, send_file, render_template
import fitz  # PyMuPDF
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)

# Directory for storing uploaded and modified PDFs
UPLOAD_FOLDER = 'uploads/'
MODIFIED_FOLDER = 'modified/'

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MODIFIED_FOLDER'] = MODIFIED_FOLDER

# Ensure the folders exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(MODIFIED_FOLDER, exist_ok=True)

def modify_pdf(input_pdf, output_pdf, old_word, new_word, vertical_offset=2):
    # Open the original PDF
    doc = fitz.open(input_pdf)
    
    # Iterate over each page in the document
    for page_num in range(len(doc)):
        page = doc.load_page(page_num)  # Load the page
        
        # Search for the old word in the document
        text_instances = page.search_for(old_word)
        
        for inst in text_instances:
            # The bounding box of the old word (position and size)
            rect = inst  # The bounding box of the old word
            
            # Erase the old word by drawing a white rectangle over it
            page.draw_rect(rect, color=(1, 1, 1), fill=True)  # White rectangle (fill=True)
            
            # Retrieve the font size of the old word
            font_size = rect.height  # Approximation based on the height of the bounding box
            
            # Adjust the vertical position (move the new word slightly down or up)
            new_y_position = rect.y1 + vertical_offset  # Move the y-coordinate by vertical_offset
            
            # Insert the new word at the adjusted position
            page.insert_text(
                (rect.x0, new_y_position),  # Insert at the bottom-left corner, adjusted vertically
                new_word,  # The new word to insert
                fontsize=font_size,  # Match the old word's font size
                color=(0, 0, 0)  # Black color for the new word
            )
    
    # Save the modified PDF
    doc.save(output_pdf)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_pdf():
    if 'pdf' not in request.files:
        return "No file part", 400
    file = request.files['pdf']
    if file.filename == '':
        return "No selected file", 400

    # Secure the filename and save the uploaded file
    filename = secure_filename(file.filename)
    input_pdf_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(input_pdf_path)

    # Get form data for old_word, new_word, and vertical_offset
    old_word = request.form['old_word']
    new_word = request.form['new_word']
    vertical_offset = int(request.form.get('vertical_offset', 2))  # Default to 2 if not provided
    
    # Prepare the output file path
    output_pdf_path = os.path.join(app.config['MODIFIED_FOLDER'], f"modified_{filename}")
    
    # Modify the PDF
    modify_pdf(input_pdf_path, output_pdf_path, old_word, new_word, vertical_offset)
    
    # Send the modified PDF back to the user
    return send_file(output_pdf_path, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
