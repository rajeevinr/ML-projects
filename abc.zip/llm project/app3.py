import fitz  # PyMuPDF

def modify_pdf(input_pdf, output_pdf, old_word, new_word):
    # Open the original PDF
    doc = fitz.open(input_pdf)
    
    # Iterate over each page in the document
    for page_num in range(len(doc)):
        page = doc.load_page(page_num)  # Load the page
        
        # Search for the text and replace it
        text_instances = page.search_for(old_word)  # Search for the word
        
        for inst in text_instances:
            # This will replace the old word with the new word
            # Draw the new word over the old one (hides the old word)
            page.insert_text(inst[:2], new_word, fontsize=12, color=(0, 0, 0))
    
    # Save the modified PDF
    doc.save(output_pdf)
    print(f"Modified PDF saved as: {output_pdf}")

# Example usage
input_pdf = "310 Freight Invoice Version 4010.pdf"
output_pdf = "modified_output.pdf"
old_word = "Freight"
new_word = "abc"

modify_pdf(input_pdf, output_pdf, old_word, new_word)
