import PyPDF2

def extract_text_from_pdf(pdf_path):
    with open(pdf_path, 'rb') as pdf_file:
        pdf_reader = PyPDF2.PdfReader(pdf_file)
        text = ""
        for page_num in range(len(pdf_reader.pages)):
            page = pdf_reader.pages[page_num]
            text += page.extract_text()
    return text

import openai
openai.api_key = "AIzaSyACRAy0-W0Rt5b53I3kh4cbz2kS2VDDH4A"

def chatbot_response(user_input, resume_text):
    prompt = f"You are a helpful AI assistant. I am providing you with my resume: \n\n{resume_text}\n\nBased on my resume, answer the following question: \n\n{user_input}"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=1024,
        n=1,
        stop=None,
        temperature=0.7,
    )
    return response.choices[0].text.strip()

import streamlit as st

def main():
    st.title("Resume Chatbot")

    # Upload PDF file
    pdf_file = st.file_uploader("Upload your resume", type="pdf")

    if pdf_file is not None:
        resume_text = extract_text_from_pdf(pdf_file)

        # Get user input
        user_input = st.text_input("Ask me anything about my resume:")

        if user_input:
            response = chatbot_response(user_input, resume_text)
            st.text_area("Chatbot Response:", value=response, height=200)

if __name__ == "__main__":
    main()