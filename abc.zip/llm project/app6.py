import fitz
from transformers import pipeline

nlp = pipeline("fill-mask", model="bert-base-uncased")

def ai_replace_word(text, old_word, new_word):
    """
    Use AI to intelligently replace words in a given text based on context.
    """
    masked_text = text.replace(old_word, "[MASK]")
    predictions = nlp(masked_text)
    
    for prediction in predictions:
        if prediction['token_str'] == old_word:
            print(f"Suggested replacement: {new_word}")
            return text.replace(old_word, new_word)
    return text

def modify_pdf(input_pdf, output_pdf, old_word, new_word):
    doc = fitz.open(input_pdf)
    
    for page_num in range(len(doc)): 
        page = doc.load_page(page_num) 
        
        text_instances = page.search_for(old_word)
        
        for inst in text_instances:
            rect = inst
            
            text_info = page.get_text("dict", clip=rect)
            if text_info['blocks']:
                block = text_info['blocks'][0]
                surrounding_text = block['lines'][0]['spans'][0]['text']
                
                modified_text = ai_replace_word(surrounding_text, old_word, new_word)
                
                page.draw_rect(rect, color=(1, 1, 1), fill=True)
                page.insert_text(rect[:2], modified_text, fontsize=12, fontname="helv", color=(0, 0, 0))
    
    doc.save(output_pdf)
    print(f"Modified PDF saved as: {output_pdf}")

input_pdf = "310 Freight Invoice Version 4010.pdf"
output_pdf = "modified_output.pdf"
old_word = "Freight"
new_word = "abc"

modify_pdf(input_pdf, output_pdf, old_word, new_word)
