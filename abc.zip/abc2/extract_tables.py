import pdfplumber
import re

def extract_tables_from_scattered_pdf(pdf_path):
    """
    Extract tables from a PDF with scattered data, organizing attributes and corresponding information.
   
    Args:
        pdf_path (str): Path to the PDF file.
    Returns:
        list: A list of extracted tables, each represented as a list of dictionaries (rows).
    """
    tables = []

    with pdfplumber.open(pdf_path) as pdf:
        for page_num, page in enumerate(pdf.pages):
            print(f"Processing page {page_num + 1}...")
            text_objects = page.extract_words(x_tolerance=3, y_tolerance=3)
           
            # Group words into lines by their y-coordinate
            lines = {}
            for obj in text_objects:
                y_coord = round(obj['top'], 1)  # Approximate Y-coordinate
                if y_coord not in lines:
                    lines[y_coord] = []
                lines[y_coord].append(obj)
           
            # Sort lines by Y-coordinate
            sorted_lines = sorted(lines.items(), key=lambda x: x[0])

            # Process lines into a table
            table = []
            for _, line in sorted_lines:
                # Extract text and sort by X-coordinate
                row = sorted(line, key=lambda x: x['x0'])
                row_text = [cell['text'] for cell in row]
                table.append(row_text)
           
            # Filter and format the table
            filtered_table = [row for row in table if len(row) > 1]  # Filter rows with single elements
            if filtered_table:
                tables.append(filtered_table)
   
    return tables


def print_tables(tables):
    """
    Pretty print the extracted tables.
   
    Args:
        tables (list): List of tables extracted from the PDF.
    """
    for idx, table in enumerate(tables):
        print(f"\nTable {idx + 1}:")
        for row in table:
            print("\t".join(row))


# Path to your PDF
pdf_path = "abc2/310 Freight Invoice Version 4010.pdf"

# Extract and display tables
extracted_tables = extract_tables_from_scattered_pdf(pdf_path)
print_tables(extracted_tables)