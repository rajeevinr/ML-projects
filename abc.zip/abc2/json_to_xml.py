import json
import xml.etree.ElementTree as ET

def json_to_xml(json_obj, root_element="root"):
    def dict_to_xml(tag, d):
        # Create the root element
        elem = ET.Element(tag)
        for key, value in d.items():
            if isinstance(value, dict):
                # Recursive call if the value is a nested dictionary
                child_elem = dict_to_xml(key, value)
                elem.append(child_elem)
            else:
                # Add the value as a text node
                child_elem = ET.SubElement(elem, key)
                child_elem.text = str(value)
        return elem

    # If the input is a dictionary, start the conversion process
    if isinstance(json_obj, dict):
        root = dict_to_xml(root_element, json_obj)
    else:
        raise ValueError("Input should be a dictionary")

    # Create a string representation of the XML
    tree = ET.ElementTree(root)
    return ET.tostring(root, encoding='unicode', method='xml')

# Example usage
json_data = {
  "first_name": "John",
  "last_name": "Smith",
  "is_alive": True,
  "age": 27,
  "address": {
    "street_address": "21 2nd Street",
    "city": "New York",
    "state": "NY",
    "postal_code": "10021-3100"
  },
  "phone_numbers": [
    {
      "type": "home",
      "number": "212 555-1234"
    },
    {
      "type": "office",
      "number": "646 555-4567"
    }
  ],
  "children": [
    "Catherine",
    "Thomas",
    "Trevor"
  ],
  "spouse": None
}

xml_output = json_to_xml(json_data, "person")
print(xml_output)
