import camelot
import os

def extract_table_schema(pdf_path, output_csv_folder="output_tables"):
    """
    Extract tables from a PDF, identify schema attributes, and organize information.

    Args:
        pdf_path (str): Path to the PDF file.
        output_csv_folder (str): Folder to save extracted tables in CSV format.
    Returns:
        list: A list of dictionaries containing table schemas.
    """
    if not os.path.exists(output_csv_folder):
        os.makedirs(output_csv_folder)
   
    try:
        # Extract tables using Camelot
        tables = camelot.read_pdf(pdf_path, pages="all", flavor="stream")
       
        if not tables:
            print("No tables found in the PDF.")
            return []

        schema_list = []

        for i, table in enumerate(tables):
            # Save the table to a CSV for further inspection if needed
            table_path = os.path.join(output_csv_folder, f"table_{i+1}.csv")
            table.to_csv(table_path)
            print(f"Table {i+1} saved to {table_path}")
           
            # Extract table data into a schema
            schema = {}
            table_data = table.df  # Extract the data frame of the table

            # Assume first row contains headers
            headers = table_data.iloc[0]
            for idx, header in enumerate(headers):
                column_data = table_data.iloc[1:, idx].tolist()
                schema[header] = column_data

            schema_list.append(schema)

        print(f"Extracted {len(tables)} tables from the PDF.")
        return schema_list

    except Exception as e:
        print(f"An error occurred: {e}")
        return []

# Path to the PDF file
pdf_file_path = "abc2/310 Freight Invoice Version 4010.pdf"

# Extract tables and their schemas
schemas = extract_table_schema(pdf_file_path)

# Print the schemas
for idx, schema in enumerate(schemas):
    print(f"\nSchema for Table {idx + 1}:")
    for attribute, values in schema.items():
        print(f"{attribute}: {values}")
