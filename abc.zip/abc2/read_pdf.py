from pypdf import PdfReader

reader = PdfReader('310 Freight Invoice Version 4010.pdf')
print(len(reader.pages))
# text = ""
# for _ in range(len(reader.pages)):
#     page = reader.pages[_]
#     text += page.extract_text()


print(reader.pages[5])