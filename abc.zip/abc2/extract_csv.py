from pypdf import PdfReader
import re
import pandas as pd

reader = PdfReader('310 Freight Invoice Version 4010.pdf')
# print(f"Total number of pages: {len(reader.pages)}")

text = ""
for page_num in range(len(reader.pages)):
    page = reader.pages[page_num]
    text += page.extract_text()

# print(text[:1000])

def extract_table_data(text):
    lines = text.split('\n')

    table_data = []

    for line in lines:
        row = re.split(r'\s{2,}', line.strip())

        if len(row) > 1:
            table_data.append(row)

    return table_data

table_data = extract_table_data(text)

df = pd.DataFrame(table_data)

# print(df.head())

df.to_csv('extracted_invoice_data.csv', index=False)